addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('Files/futo.txd',true)
        engineImportTXD(txd, 410)
 
        local dff = engineLoadDFF('Files/futo.dff', 0)
        engineReplaceModel(dff, 410)

	end 
)
