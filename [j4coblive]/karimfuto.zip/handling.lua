-- Futo vehicle model ID in MTA:SA
local FUTO_MODEL_ID = 576

-- Function to apply custom handling to a Futo vehicle
function applyCustomHandling(vehicle)
    if getElementModel(vehicle) ~= FUTO_MODEL_ID then return end -- Only apply to Futo vehicles

    -- Apply the handling values from the provided data
    setVehicleHandling(vehicle, "mass", 1400.0)
    setVehicleHandling(vehicle, "turnMass", 3500.0)
    setVehicleHandling(vehicle, "dragCoeff", 2.0)
    setVehicleHandling(vehicle, "centerOfMass", {0.0, 0.2, -0.2})
    setVehicleHandling(vehicle, "percentSubmerged", 75)
    setVehicleHandling(vehicle, "tractionMultiplier", 1.0)
    setVehicleHandling(vehicle, "tractionLoss", 1.0)
    setVehicleHandling(vehicle, "tractionBias", 0.5)
    setVehicleHandling(vehicle, "numberOfGears", 5)
    setVehicleHandling(vehicle, "maxVelocity", 235.0)
    setVehicleHandling(vehicle, "engineAcceleration", 25.0)
    setVehicleHandling(vehicle, "engineInertia", 10.0)
    setVehicleHandling(vehicle, "driveType", "rwd")
    setVehicleHandling(vehicle, "engineType", "petrol")
    setVehicleHandling(vehicle, "brakeDeceleration", 20.0)
    setVehicleHandling(vehicle, "brakeBias", 0.5)
    setVehicleHandling(vehicle, "ABS", true)
    setVehicleHandling(vehicle, "steeringLock", 35.0)
    setVehicleHandling(vehicle, "suspensionForceLevel", 1.0)
    setVehicleHandling(vehicle, "suspensionDamping", 2.0)
    setVehicleHandling(vehicle, "suspensionHighSpeedDamping", 0.0)
    setVehicleHandling(vehicle, "suspensionUpperLimit", 0.1)
    setVehicleHandling(vehicle, "suspensionLowerLimit", -0.05)
    setVehicleHandling(vehicle, "suspensionFrontRearBias", 0.5)
    setVehicleHandling(vehicle, "suspensionAntiDiveMultiplier", 0.5)
    setVehicleHandling(vehicle, "seatOffsetDistance", 0.2)
    setVehicleHandling(vehicle, "collisionDamageMultiplier", 0.2)
    -- Note: modelFlags and handlingFlags are not directly supported by setVehicleHandling, but can be applied via setModelHandling if needed
end

-- Apply handling when a player starts entering a vehicle
addEventHandler("onVehicleStartEnter", root, function(player, seat, jacked)
    applyCustomHandling(source)
end)

-- Apply handling to existing vehicles when the resource starts
addEventHandler("onResourceStart", resourceRoot, function()
    for _, vehicle in ipairs(getElementsByType("vehicle")) do
        applyCustomHandling(vehicle)
    end
end)

-- Display chatbox message when the map starts
addEventHandler("onGamemodeMapStart", root, function()
    outputChatBox("This map has modified handling!", root, 0, 255, 0)
end)